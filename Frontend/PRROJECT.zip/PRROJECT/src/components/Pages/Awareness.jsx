export function Awareness() {
  return (
    <div className="bg-info vh-100 d-flex justify-content-center align-items-center">
        <h1>Awareness</h1>
    </div>
  );
}
