export function Education() {
  return (
    <div className="bg-danger vh-100 d-flex justify-content-center align-items-center">
      <h1>Education</h1>
    </div>
  );
}
