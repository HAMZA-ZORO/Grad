export function Training() {
  return (
    <div className="bg-success vh-100 d-flex justify-content-center align-items-center">
      <h1>Training</h1>
    </div>
  );
}
