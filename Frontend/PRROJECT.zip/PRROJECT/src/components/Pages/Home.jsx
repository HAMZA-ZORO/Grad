export function Home() {
  return (
    <div className="bg-warning vh-100 d-flex justify-content-center align-items-center">
      <h1>Home</h1>
    </div>
  );
}
