import "./login-register.css";
import { Link } from "react-router-dom";

export function Login() {
  return (
    <div className="login-register">
      <div className="wrapper">
        <h2>Login</h2>
        <form action="/login" method="POST">
          <div className="input-box">
            <input
              type="text"
              name="email"
              placeholder="Enter your email"
              required
            />
          </div>
          <div className="input-box">
            <input
              type="password"
              name="password"
              placeholder="Enter your password"
              required
            />
          </div>
          <div className="input-box button">
            <input type="Submit" value="Log in" />
          </div>
          <div className="text">
            <h3>
              Create New Account <Link to="register"> Create</Link>
            </h3>
          </div>
        </form>
      </div>
    </div>
  );
}
