import "./login-register.css";
export function Register() {
  return (
    <div className="login-register">
      <div className="wrapper">
        <h2>Registration</h2>
        <form action="/register" method="POST">
          <div className="input-box">
            <input
              type="text"
              name="name"
              placeholder="Enter your name"
              required
            />
          </div>
          <div className="input-box">
            <input
              type="text"
              name="email"
              placeholder="Enter your email"
              required
            />
          </div>
          <div className="input-box">
            <input
              type="password"
              name="password"
              placeholder="Create password"
              required
            />
          </div>
          <div className="input-box">
            <select name="level" id="level" required>
              <span className="material-symbols-outlined">arrow_drop_down</span>
              <option value="" disabled selected hidden>
                Choose your level
              </option>
              <option value="1">I know nothing in Tech or Security</option>
              <option value="2">
                I know a little bit and I want to protect Myself
              </option>
              <option value="3">I am Learning Secure Coding</option>
            </select>
          </div>
          <div className="input-box button">
            <input type="Submit" value="Register Now" />
          </div>
          <div className="text">
            <h3>
              Already have an account? <a href="login.html">Login now</a>
            </h3>
          </div>
        </form>
      </div>
    </div>
  );
}
