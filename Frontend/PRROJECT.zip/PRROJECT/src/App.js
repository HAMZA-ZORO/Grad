import { Route, Routes } from "react-router-dom";
import "./App.css";
import { Navbar } from "./components/Navbar";
import { Home } from "./components/Pages/Home";
import { Awareness } from "./components/Pages/Awareness";
import { Education } from "./components/Pages/Education";
import { Login } from "./components/Pages/Login";
import { PageNotFound } from "./components/Pages/PageNotFound";
import Questions from "./components/Questions";
import { Register } from "./components/Pages/Register";
export function App() {
  return (
    <div className="App">
      <Navbar />
      <Routes>
        <Route path="/" element={<PageNotFound />} />
        <Route path="/home" element={<Home />} />
        <Route path="/awareness" element={<Awareness />} />
        <Route path="/education" element={<Education />} />
        <Route path="/trivia-quiz" element={<Questions />} />
        <Route path="/login" element={<Login />}></Route>
        <Route path="/register" element={<Register />} />
      </Routes>
    </div>
  );
}
